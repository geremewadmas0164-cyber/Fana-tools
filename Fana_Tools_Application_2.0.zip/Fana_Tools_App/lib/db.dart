import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class AppDb {
  static Database? _db;

  static Future<Database> get db async {
    if (_db != null) return _db!;
    final path = join(await getDatabasesPath(), 'fana_tools.db');
    _db = await openDatabase(path, version: 1, onCreate: (db, v) async {
      await db.execute('''
        CREATE TABLE members(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          full_name TEXT NOT NULL,
          phone TEXT,
          member_type TEXT NOT NULL,
          registration_date TEXT NOT NULL
        )
      ''');
      await db.execute('''
        CREATE TABLE finance(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          trans_date TEXT NOT NULL,
          category TEXT NOT NULL,
          source_or_purpose TEXT NOT NULL,
          type TEXT NOT NULL,
          amount REAL NOT NULL
        )
      ''');
      await db.execute('''
        CREATE TABLE iga_projects(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          project_name TEXT NOT NULL,
          status TEXT NOT NULL,
          monthly_revenue REAL NOT NULL DEFAULT 0
        )
      ''');
      await db.execute('''
        CREATE TABLE support_projects(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          title TEXT NOT NULL,
          target_beneficiaries INTEGER NOT NULL DEFAULT 0,
          budget REAL NOT NULL DEFAULT 0,
          status TEXT NOT NULL
        )
      ''');
      await db.execute('''
        CREATE TABLE users(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          username TEXT UNIQUE NOT NULL,
          password TEXT NOT NULL,
          role TEXT NOT NULL
        )
      ''');
      await db.insert('users', {'username':'admin','password':'1234','role':'Administrator'});
      await db.insert('iga_projects', {'project_name':'ኮንቲነር ኪራይ','status':'በስራ ላይ','monthly_revenue':9500});
      await db.insert('iga_projects', {'project_name':'የእንስሳት ማድለቢያ','status':'በስራ ላይ','monthly_revenue':12000});
      await db.insert('iga_projects', {'project_name':'የወፍጮ ኪራይ','status':'በስራ ላይ','monthly_revenue':12000});
      await db.insert('iga_projects', {'project_name':'አትክልትና ፍራፍሬ','status':'በማልማት ላይ','monthly_revenue':11500});
      await db.insert('support_projects', {'title':'የመድኃኒትና የምግብ ድጋፍ','target_beneficiaries':50,'budget':100000,'status':'በስራ ላይ'});
    });
    return _db!;
  }

  static Future<int> add(String table, Map<String,Object?> values) async => (await db).insert(table, values);
  static Future<int> update(String table, Map<String,Object?> values, int id) async =>
      (await db).update(table, values, where:'id=?', whereArgs:[id]);
  static Future<int> delete(String table, int id) async =>
      (await db).delete(table, where:'id=?', whereArgs:[id]);
  static Future<List<Map<String,Object?>>> all(String table) async =>
      (await db).query(table, orderBy:'id DESC');

  static Future<Map<String,double>> financeTotals() async {
    final d = await db;
    final inc = Sqflite.firstIntValue(await d.rawQuery("SELECT COUNT(*) FROM finance WHERE type='ገቢ'")) ?? 0;
    final incomeRows = await d.rawQuery("SELECT COALESCE(SUM(amount),0) total FROM finance WHERE type='ገቢ'");
    final expenseRows = await d.rawQuery("SELECT COALESCE(SUM(amount),0) total FROM finance WHERE type='ወጪ'");
    return {'income': (incomeRows.first['total'] as num).toDouble(), 'expense': (expenseRows.first['total'] as num).toDouble(), 'records': inc.toDouble()};
  }
}

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'db.dart';

void main() => runApp(const FanaToolsApp());

class FanaToolsApp extends StatelessWidget {
  const FanaToolsApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner:false,
    title:'Fana Tools',
    theme:ThemeData(colorScheme:ColorScheme.fromSeed(seedColor:Colors.teal),useMaterial3:true),
    home:const LoginPage(),
  );
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override State<LoginPage> createState()=>_LoginPageState();
}
class _LoginPageState extends State<LoginPage>{
  final u=TextEditingController(text:'admin'), p=TextEditingController(text:'1234');
  bool busy=false, hide=true;
  Future<void> login() async {
    setState(()=>busy=true);
    final rows=await (await AppDb.db).query('users',where:'username=? AND password=?',whereArgs:[u.text.trim(),p.text]);
    if(!mounted)return;
    setState(()=>busy=false);
    if(rows.isNotEmpty) Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>HomePage(role:rows.first['role'] as String)));
    else ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('የተጠቃሚ ስም ወይም የይለፍ ቃል ተሳስቷል')));
  }
  @override Widget build(BuildContext c)=>Scaffold(
    body:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(24),child:Column(children:[
      CircleAvatar(radius:48,backgroundColor:Colors.red.shade50,child:const Icon(Icons.favorite,color:Colors.red,size:50)),
      const SizedBox(height:12),const Text('Fana Tools',style:TextStyle(fontSize:30,fontWeight:FontWeight.bold,color:Colors.teal)),
      const Text('ከኔ ይልቅ ለኔ ትውልድ',style:TextStyle(fontSize:16)),
      const SizedBox(height:30),
      TextField(controller:u,decoration:const InputDecoration(labelText:'የተጠቃሚ ስም',prefixIcon:Icon(Icons.person),border:OutlineInputBorder())),
      const SizedBox(height:12),
      TextField(controller:p,obscureText:hide,decoration:InputDecoration(labelText:'የይለፍ ቃል',prefixIcon:const Icon(Icons.lock),suffixIcon:IconButton(onPressed:()=>setState(()=>hide=!hide),icon:Icon(Icons.visibility)),border:const OutlineInputBorder())),
      const SizedBox(height:20),SizedBox(width:double.infinity,height:50,child:FilledButton(onPressed:busy?null:login,child:Text(busy?'...':'ግባ'))),
      const SizedBox(height:12),const Text('መጀመሪያ መግቢያ፡ admin / 1234',style:TextStyle(color:Colors.grey))
    ]))),
  );
}

class HomePage extends StatefulWidget{
  final String role; const HomePage({super.key,required this.role});
  @override State<HomePage> createState()=>_HomePageState();
}
class _HomePageState extends State<HomePage>{
  int idx=0;
  final pages=const [Dashboard(),MembersPage(),IgaPage(),FinancePage(),ProjectsPage()];
  @override Widget build(BuildContext c)=>Scaffold(
    appBar:AppBar(title:const Text('Fana Tools',style:TextStyle(fontWeight:FontWeight.bold)),actions:[Center(child:Padding(padding:const EdgeInsets.only(right:12),child:Text(widget.role))),IconButton(onPressed:()=>Navigator.pushReplacement(c,MaterialPageRoute(builder:(_)=>const LoginPage())),icon:const Icon(Icons.logout))]),
    body:pages[idx],
    bottomNavigationBar:NavigationBar(selectedIndex:idx,onDestinationSelected:(i)=>setState(()=>idx=i),destinations:const[
      NavigationDestination(icon:Icon(Icons.dashboard),label:'ዋና ገጽ'),
      NavigationDestination(icon:Icon(Icons.people),label:'አባላት'),
      NavigationDestination(icon:Icon(Icons.store),label:'ገቢ ማስገኛ'),
      NavigationDestination(icon:Icon(Icons.account_balance_wallet),label:'ፋይናንስ'),
      NavigationDestination(icon:Icon(Icons.assignment),label:'ዕቅዶች'),
    ]),
  );
}

class Dashboard extends StatefulWidget{const Dashboard({super.key});@override State<Dashboard> createState()=>_DashboardState();}
class _DashboardState extends State<Dashboard>{
  int members=0, founders=0; double income=0,expense=0,iga=0;
  @override void initState(){super.initState();load();}
  Future<void> load()async{
    final d=await AppDb.db; final m=await d.query('members'); final f=await AppDb.financeTotals(); final i=await d.rawQuery("SELECT COALESCE(SUM(monthly_revenue),0) x FROM iga_projects");
    if(!mounted)return; setState((){members=m.length;founders=m.where((x)=>x['member_type']=='መስራች').length;income=f['income']!;expense=f['expense']!;iga=(i.first['x'] as num).toDouble();});
  }
  @override Widget build(BuildContext c)=>RefreshIndicator(onRefresh:load,child:ListView(padding:const EdgeInsets.all(16),children:[
    Card(color:Colors.teal,child:const Padding(padding:EdgeInsets.all(18),child:Row(children:[Icon(Icons.favorite,color:Colors.white,size:34),SizedBox(width:12),Expanded(child:Text('እንኳን ወደ Fana Tools በደህና መጡ! የማህበሩን እንቅስቃሴ በአንድ ቦታ ይቆጣጠሩ።',style:TextStyle(color:Colors.white,fontSize:15)))]))),
    const SizedBox(height:12),Wrap(spacing:10,runSpacing:10,children:[
      Stat('ጠቅላላ አባላት','$members',Colors.blue,Icons.group),
      Stat('መስራች አባላት','$founders',Colors.orange,Icons.star),
      Stat('ገቢ','${income.toStringAsFixed(0)} ብር',Colors.green,Icons.arrow_downward),
      Stat('ወጪ','${expense.toStringAsFixed(0)} ብር',Colors.red,Icons.arrow_upward),
      Stat('IGA ወርሃዊ ገቢ','${iga.toStringAsFixed(0)} ብር',Colors.teal,Icons.store),
    ]),
    const SizedBox(height:18),const Text('የስርዓቱ አላማ',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
    const SizedBox(height:8),const Text('አባላትን፣ ገቢና ወጪን፣ የገቢ ማስገኛ ፕሮጀክቶችን እና የድጋፍ ፕሮጀክቶችን በቀላሉ ለመመዝገብና ለመከታተል።')
  ]));
}
class Stat extends StatelessWidget{final String t,v;final Color color;final IconData icon;const Stat(this.t,this.v,this.color,this.icon,{super.key});@override Widget build(BuildContext c)=>SizedBox(width:MediaQuery.of(c).size.width/2-21,child:Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(icon,color:color),Text(t,style:const TextStyle(fontSize:12)),Text(v,style:TextStyle(fontSize:18,fontWeight:FontWeight.bold,color:color))]))));}

class MembersPage extends StatefulWidget{const MembersPage({super.key});@override State<MembersPage> createState()=>_MembersPageState();}
class _MembersPageState extends State<MembersPage>{
  List<Map<String,Object?>> rows=[]; String q='';
  @override void initState(){super.initState();load();}
  Future<void> load()async{rows=await AppDb.all('members');if(mounted)setState((){});}
  Future<void> form([Map<String,Object?>? old])async{
    final name=TextEditingController(text:old?['full_name']?.toString()??'');
    final phone=TextEditingController(text:old?['phone']?.toString()??''); String type=old?['member_type']?.toString()??'መደበኛ';
    await showDialog(context:context,builder:(c)=>AlertDialog(title:Text(old==null?'አዲስ አባል':'አባል አስተካክል'),content:StatefulBuilder(builder:(c,set)=>Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:name,decoration:const InputDecoration(labelText:'ሙሉ ስም')),TextField(controller:phone,keyboardType:TextInputType.phone,decoration:const InputDecoration(labelText:'ስልክ')),DropdownButton<String>(value:type,isExpanded:true,items:const[DropdownMenuItem(value:'መደበኛ',child:Text('መደበኛ')),DropdownMenuItem(value:'መስራች',child:Text('መስራች'))],onChanged:(v)=>set(()=>type=v!))])),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('ዝጋ')),FilledButton(onPressed:()async{if(name.text.trim().isEmpty)return;final vals={'full_name':name.text.trim(),'phone':phone.text.trim(),'member_type':type,'registration_date':DateTime.now().toIso8601String()};if(old==null)await AppDb.add('members',vals);else await AppDb.update('members',vals,old['id'] as int);if(c.mounted)Navigator.pop(c);await load();},child:const Text('አስቀምጥ'))]));
  }
  @override Widget build(BuildContext c){final filtered=rows.where((r){final s='${r['full_name']} ${r['phone']}'.toLowerCase();return s.contains(q.toLowerCase());}).toList();return Scaffold(floatingActionButton:FloatingActionButton.extended(onPressed:form,label:const Text('አዲስ አባል'),icon:const Icon(Icons.person_add)),body:ListView(padding:const EdgeInsets.all(12),children:[TextField(onChanged:(v)=>setState(()=>q=v),decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'በስም ወይም በስልክ ይፈልጉ',border:OutlineInputBorder())),const SizedBox(height:10),...filtered.map((r)=>Card(child:ListTile(leading:CircleAvatar(child:Text((r['full_name'] as String).substring(0,1))),title:Text(r['full_name'] as String),subtitle:Text('ስልክ፡ ${r['phone']??''} | ${r['member_type']}'),trailing:PopupMenuButton<String>(onSelected:(v)async{if(v=='edit')await form(r);else{await AppDb.delete('members',r['id'] as int);await load();}},itemBuilder:(_)=>const[PopupMenuItem(value:'edit',child:Text('አስተካክል')),PopupMenuItem(value:'delete',child:Text('ሰርዝ'))]))))]));}
}

class IgaPage extends StatefulWidget{const IgaPage({super.key});@override State<IgaPage> createState()=>_IgaPageState();}
class _IgaPageState extends State<IgaPage>{List<Map<String,Object?>> rows=[];@override void initState(){super.initState();load();}Future<void>load()async{rows=await AppDb.all('iga_projects');if(mounted)setState((){});}Future<void>form([Map<String,Object?>? old])async{final n=TextEditingController(text:old?['project_name']?.toString()??'');final rev=TextEditingController(text:old?['monthly_revenue']?.toString()??'0');String st=old?['status']?.toString()??'በስራ ላይ':'በስራ ላይ';await showDialog(context:context,builder:(c)=>AlertDialog(title:Text(old==null?'IGA ጨምር':'IGA አስተካክል'),content:StatefulBuilder(builder:(c,set)=>Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:n,decoration:const InputDecoration(labelText:'የፕሮጀክት ስም')),TextField(controller:rev,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'ወርሃዊ ገቢ')),DropdownButton<String>(value:st,isExpanded:true,items:const['በስራ ላይ','በማልማት ላይ','ተጠናቋል'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v)=>set(()=>st=v!))])),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('ዝጋ')),FilledButton(onPressed:()async{final vals={'project_name':n.text,'status':st,'monthly_revenue':double.tryParse(rev.text)??0};if(old==null)await AppDb.add('iga_projects',vals);else await AppDb.update('iga_projects',vals,old['id'] as int);if(c.mounted)Navigator.pop(c);await load();},child:const Text('አስቀምጥ'))]));}
@override Widget build(BuildContext c)=>Scaffold(floatingActionButton:FloatingActionButton.extended(onPressed:form,label:const Text('IGA ጨምር'),icon:const Icon(Icons.add_business)),body:ListView(padding:const EdgeInsets.all(12),children:rows.map((r)=>Card(child:ListTile(leading:const Icon(Icons.store,color:Colors.teal),title:Text(r['project_name'] as String),subtitle:Text('${r['status']} | ${r['monthly_revenue']} ብር/ወር'),trailing:PopupMenuButton<String>(onSelected:(v)async{if(v=='edit')await form(r);else{await AppDb.delete('iga_projects',r['id'] as int);await load();}},itemBuilder:(_)=>const[PopupMenuItem(value:'edit',child:Text('አስተካክል')),PopupMenuItem(value:'delete',child:Text('ሰርዝ'))])))).toList()));}

class FinancePage extends StatefulWidget{const FinancePage({super.key});@override State<FinancePage> createState()=>_FinancePageState();}
class _FinancePageState extends State<FinancePage>{List<Map<String,Object?>> rows=[];@override void initState(){super.initState();load();}Future<void>load()async{rows=await AppDb.all('finance');if(mounted)setState((){});}Future<void>form()async{final src=TextEditingController();final amt=TextEditingController();String type='ገቢ';await showDialog(context:context,builder:(c)=>AlertDialog(title:const Text('የፋይናንስ መዝገብ'),content:StatefulBuilder(builder:(c,set)=>Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:src,decoration:const InputDecoration(labelText:'ምንጭ / ዓላማ')),TextField(controller:amt,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'መጠን')),DropdownButton<String>(value:type,isExpanded:true,items:const[DropdownMenuItem(value:'ገቢ',child:Text('ገቢ')),DropdownMenuItem(value:'ወጪ',child:Text('ወጪ'))],onChanged:(v)=>set(()=>type=v!))])),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('ዝጋ')),FilledButton(onPressed:()async{await AppDb.add('finance',{'trans_date':DateFormat('yyyy-MM-dd').format(DateTime.now()),'category':'አጠቃላይ','source_or_purpose':src.text,'type':type,'amount':double.tryParse(amt.text)??0});if(c.mounted)Navigator.pop(c);await load();},child:const Text('አስቀምጥ'))]));}
@override Widget build(BuildContext c)=>Scaffold(floatingActionButton:FloatingActionButton.extended(onPressed:form,label:const Text('መዝገብ ጨምር'),icon:const Icon(Icons.add)),body:ListView(padding:const EdgeInsets.all(12),children:rows.map((r)=>Card(child:ListTile(leading:Icon(r['type']=='ገቢ'?Icons.arrow_downward:Icons.arrow_upward,color:r['type']=='ገቢ'?Colors.green:Colors.red),title:Text(r['source_or_purpose'] as String),subtitle:Text('${r['trans_date']} | ${r['type']}'),trailing:Text('${r['amount']} ብር',style:const TextStyle(fontWeight:FontWeight.bold)) ))).toList()));}

class ProjectsPage extends StatefulWidget{const ProjectsPage({super.key});@override State<ProjectsPage> createState()=>_ProjectsPageState();}
class _ProjectsPageState extends State<ProjectsPage>{List<Map<String,Object?>> rows=[];@override void initState(){super.initState();load();}Future<void>load()async{rows=await AppDb.all('support_projects');if(mounted)setState((){});}Future<void>form()async{final t=TextEditingController(),b=TextEditingController(),bud=TextEditingController();String st='በስራ ላይ';await showDialog(context:context,builder:(c)=>AlertDialog(title:const Text('የድጋፍ ፕሮጀክት'),content:StatefulBuilder(builder:(c,set)=>Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:t,decoration:const InputDecoration(labelText:'ርዕስ')),TextField(controller:b,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'ተጠቃሚዎች ብዛት')),TextField(controller:bud,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'በጀት')),DropdownButton<String>(value:st,isExpanded:true,items:const['የታቀደ','በስራ ላይ','ተጠናቋል'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v)=>set(()=>st=v!))])),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('ዝጋ')),FilledButton(onPressed:()async{await AppDb.add('support_projects',{'title':t.text,'target_beneficiaries':int.tryParse(b.text)??0,'budget':double.tryParse(bud.text)??0,'status':st});if(c.mounted)Navigator.pop(c);await load();},child:const Text('አስቀምጥ'))]));}
@override Widget build(BuildContext c)=>Scaffold(floatingActionButton:FloatingActionButton.extended(onPressed:form,label:const Text('ፕሮጀክት ጨምር'),icon:const Icon(Icons.add)),body:ListView(padding:const EdgeInsets.all(12),children:rows.map((r)=>Card(child:ListTile(leading:const Icon(Icons.assignment_turned_in,color:Colors.teal),title:Text(r['title'] as String),subtitle:Text('ተጠቃሚ፡ ${r['target_beneficiaries']} | በጀት፡ ${r['budget']} ብር | ${r['status']}'))).toList()));}

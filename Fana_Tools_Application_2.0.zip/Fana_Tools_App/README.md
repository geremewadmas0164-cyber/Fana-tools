# Fana Tools Mobile 2.0
ይህ ፕሮጀክት በተሰጠው Fana Tools Flutter UI መሰረት የተሰራ የAndroid/Flutter application source project ነው።

## የሚሰሩ ክፍሎች
- Login
- Dashboard ከSQLite የሚያነብ እውነተኛ ስታቲስቲክስ
- Members CRUD + Search
- IGA CRUD
- Finance records
- Support Projects
- Offline SQLite database
- Amharic UI
- HIV-awareness branding
- Slogan: ከኔ ይልቅ ለኔ ትውልድ

## Login
username: admin
password: 1234

## Build
flutter pub get
flutter run
flutter build apk --release

የAPK ማምረት በFlutter/Android SDK ያለበት ኮምፒዩተር ላይ ይፈጸማል።

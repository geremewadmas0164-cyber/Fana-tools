# Fana Tools 3.0
የFana Tools ማህበር አስተዳደር አፕ።
- አማርኛ UI
- Login: admin / 1234
- Offline SQLite
- Dashboard
- አባላት + search + edit/delete
- ፋይናንስ
- IGA
- ፕሮጀክቶች

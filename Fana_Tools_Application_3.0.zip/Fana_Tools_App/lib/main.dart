import 'package:flutter/material.dart';
import 'db.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppDb.db;
  runApp(const FanaToolsApp());
}

class FanaToolsApp extends StatelessWidget {
  const FanaToolsApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner:false,
    title:'Fana Tools',
    theme:ThemeData(useMaterial3:true, colorSchemeSeed:Colors.teal),
    home:const LoginPage(),
  );
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override State<LoginPage> createState()=>_LoginPageState();
}
class _LoginPageState extends State<LoginPage> {
  final u=TextEditingController(text:'admin');
  final p=TextEditingController(text:'1234');
  bool busy=false, hide=true;
  Future<void> go() async {
    setState(()=>busy=true);
    final ok=await AppDb.login(u.text,p.text);
    if(!mounted)return;
    setState(()=>busy=false);
    if(ok) {
      Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>const HomePage()));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('የመግቢያ መረጃ ልክ አይደለም')));
    }
  }
  @override Widget build(BuildContext context)=>Scaffold(
    body:SafeArea(child:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(24),child:Column(children:[
      CircleAvatar(radius:45,child:Icon(Icons.favorite,size:48,color:Theme.of(context).colorScheme.primary)),
      const SizedBox(height:12),
      const Text('FANA TOOLS',style:TextStyle(fontSize:28,fontWeight:FontWeight.bold)),
      const Text('ከኔ ይልቅ ለኔ ትውልድ',style:TextStyle(fontSize:17,fontWeight:FontWeight.w600)),
      const SizedBox(height:28),
      TextField(controller:u,decoration:const InputDecoration(labelText:'የተጠቃሚ ስም',prefixIcon:Icon(Icons.person),border:OutlineInputBorder())),
      const SizedBox(height:12),
      TextField(controller:p,obscureText:hide,decoration:InputDecoration(labelText:'የይለፍ ቃል',prefixIcon:const Icon(Icons.lock),suffixIcon:IconButton(onPressed:()=>setState(()=>hide=!hide),icon:Icon(hide?Icons.visibility:Icons.visibility_off)),border:const OutlineInputBorder())),
      const SizedBox(height:18),
      SizedBox(width:double.infinity,height:50,child:FilledButton(onPressed:busy?null:go,child:Text(busy?'እየገባ...':'ግባ'))),
      const SizedBox(height:10),
      const Text('መጀመሪያ መግቢያ: admin / 1234')
    ])))
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState()=>_HomePageState();
}
class _HomePageState extends State<HomePage> {
  int i=0;
  final pages=const [DashboardPage(),MembersPage(),FinancePage(),IgaPage(),ProjectsPage()];
  final titles=const ['ዳሽቦርድ','አባላት','ፋይናንስ','IGA','ፕሮጀክቶች'];
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:Text('Fana Tools • ${titles[i]}'),actions:[
      IconButton(onPressed:()=>Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>const LoginPage())),icon:const Icon(Icons.logout))
    ]),
    body:pages[i],
    bottomNavigationBar:NavigationBar(selectedIndex:i,onDestinationSelected:(x)=>setState(()=>i=x),destinations:const[
      NavigationDestination(icon:Icon(Icons.dashboard),label:'ዳሽቦርድ'),
      NavigationDestination(icon:Icon(Icons.people),label:'አባላት'),
      NavigationDestination(icon:Icon(Icons.account_balance_wallet),label:'ፋይናንስ'),
      NavigationDestination(icon:Icon(Icons.store),label:'IGA'),
      NavigationDestination(icon:Icon(Icons.folder),label:'ፕሮጀክቶች'),
    ])
  );
}

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});
  @override State<DashboardPage> createState()=>_DashboardPageState();
}
class _DashboardPageState extends State<DashboardPage> {
  Map<String,double> t={};
  @override void initState(){super.initState();load();}
  Future<void> load()async{t=await AppDb.totals();if(mounted)setState((){});}
  Widget c(String a,String b,IconData icon)=>Card(child:ListTile(leading:CircleAvatar(child:Icon(icon)),title:Text(a),subtitle:Text(b,style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold))));
  @override Widget build(BuildContext context)=>RefreshIndicator(onRefresh:load,child:ListView(padding:const EdgeInsets.all(12),children:[
    const Card(child:Padding(padding:EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text('እንኳን ወደ Fana Tools በደህና መጡ',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
      SizedBox(height:6),Text('የማህበሩን አባላት፣ ፋይናንስ፣ IGA እና ፕሮጀክቶች ያስተዳድሩ።')
    ]))),
    c('ጠቅላላ አባላት','${(t['members']??0).toInt()}',Icons.people),
    c('ጠቅላላ ገቢ','${(t['income']??0).toStringAsFixed(2)} ብር',Icons.trending_up),
    c('ጠቅላላ ወጪ','${(t['expense']??0).toStringAsFixed(2)} ብር',Icons.trending_down),
    c('ቀሪ ሂሳብ','${(t['balance']??0).toStringAsFixed(2)} ብር',Icons.account_balance),
  ]));
}

class MembersPage extends StatefulWidget {
  const MembersPage({super.key});
  @override State<MembersPage> createState()=>_MembersPageState();
}
class _MembersPageState extends State<MembersPage> {
  List<Map<String,Object?>> rows=[];
  final search=TextEditingController();
  @override void initState(){super.initState();load();}
  Future<void> load()async{rows=await AppDb.members(search.text);if(mounted)setState((){});}
  Future<void> form([Map<String,Object?>? old])async{
    final n=TextEditingController(text:old?['name']?.toString()??'');
    final ph=TextEditingController(text:old?['phone']?.toString()??'');
    final ty=TextEditingController(text:old?['type']?.toString()??'አባል');
    final ok=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(
      title:Text(old==null?'አዲስ አባል':'አባል አስተካክል'),
      content:Column(mainAxisSize:MainAxisSize.min,children:[
        TextField(controller:n,decoration:const InputDecoration(labelText:'ሙሉ ስም')),
        TextField(controller:ph,decoration:const InputDecoration(labelText:'ስልክ')),
        TextField(controller:ty,decoration:const InputDecoration(labelText:'የአባልነት አይነት'))
      ]),
      actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('ሰርዝ')),
        FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('አስቀምጥ'))]));
    if(ok==true&&n.text.trim().isNotEmpty){
      final x={'name':n.text.trim(),'phone':ph.text.trim(),'type':ty.text.trim(),'joined':DateTime.now().toIso8601String()};
      if(old==null)await AppDb.addMember(x);else await AppDb.updateMember(old['id'] as int,x);
      load();
    }
  }
  @override Widget build(BuildContext context)=>Column(children:[
    Padding(padding:const EdgeInsets.all(10),child:TextField(controller:search,onChanged:(_)=>load(),decoration:const InputDecoration(labelText:'አባል ፈልግ',prefixIcon:Icon(Icons.search),border:OutlineInputBorder()))),
    Expanded(child:ListView.builder(itemCount:rows.length,itemBuilder:(c,i){
      final r=rows[i];
      return Card(child:ListTile(leading:const CircleAvatar(child:Icon(Icons.person)),title:Text('${r['name']}'),subtitle:Text('${r['phone']??''} • ${r['type']??''}'),trailing:PopupMenuButton<String>(
        onSelected:(v)async{if(v=='edit'){await form(r);}else{await AppDb.deleteMember(r['id'] as int);load();}},
        itemBuilder:(_)=>const[PopupMenuItem(value:'edit',child:Text('አስተካክል')),PopupMenuItem(value:'delete',child:Text('ሰርዝ'))]
      )));
    })),
    Padding(padding:const EdgeInsets.all(10),child:Align(alignment:Alignment.bottomRight,child:FloatingActionButton(onPressed:()=>form(),child:const Icon(Icons.add))))
  ]);
}

class FinancePage extends StatefulWidget {
  const FinancePage({super.key});
  @override State<FinancePage> createState()=>_FinancePageState();
}
class _FinancePageState extends State<FinancePage>{
  List<Map<String,Object?>> rows=[];
  @override void initState(){super.initState();load();}
  Future<void> load()async{rows=await AppDb.finance();if(mounted)setState((){});}
  Future<void> add()async{
    final a=TextEditingController(),cat=TextEditingController(),note=TextEditingController();
    String kind='income';
    final ok=await showDialog<bool>(context:context,builder:(_)=>StatefulBuilder(builder:(c,s)=>AlertDialog(
      title:const Text('የፋይናንስ መዝገብ'),content:Column(mainAxisSize:MainAxisSize.min,children:[
        DropdownButtonFormField<String>(value:kind,items:const[DropdownMenuItem(value:'income',child:Text('ገቢ')),DropdownMenuItem(value:'expense',child:Text('ወጪ'))],onChanged:(v)=>s(()=>kind=v!),decoration:const InputDecoration(labelText:'አይነት')),
        TextField(controller:a,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'መጠን በብር')),
        TextField(controller:cat,decoration:const InputDecoration(labelText:'ምድብ')),
        TextField(controller:note,decoration:const InputDecoration(labelText:'ማብራሪያ'))
      ]),actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('ሰርዝ')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('አስቀምጥ'))])));
    if(ok==true){await AppDb.addFinance({'kind':kind,'amount':double.tryParse(a.text)??0,'category':cat.text,'note':note.text,'date':DateTime.now().toIso8601String()});load();}
  }
  @override Widget build(BuildContext context)=>Scaffold(body:ListView.builder(padding:const EdgeInsets.all(8),itemCount:rows.length,itemBuilder:(c,i){
    final r=rows[i];final inc=r['kind']=='income';
    return Card(child:ListTile(leading:Icon(inc?Icons.add_circle:Icons.remove_circle),title:Text('${r['amount']} ብር'),subtitle:Text('${inc?'ገቢ':'ወጪ'} • ${r['category']??''}'),trailing:IconButton(onPressed:()async{await AppDb.deleteFinance(r['id'] as int);load();},icon:const Icon(Icons.delete_outline))));
  }),floatingActionButton:FloatingActionButton(onPressed:add,child:const Icon(Icons.add)));
}

class IgaPage extends StatefulWidget {
  const IgaPage({super.key});
  @override State<IgaPage> createState()=>_IgaPageState();
}
class _IgaPageState extends State<IgaPage>{
  List<Map<String,Object?>> rows=[];
  @override void initState(){super.initState();load();}
  Future<void> load()async{rows=await AppDb.iga();if(mounted)setState((){});}
  Future<void> add()async{
    final n=TextEditingController(),a=TextEditingController(),note=TextEditingController();
    final ok=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(title:const Text('አዲስ IGA'),content:Column(mainAxisSize:MainAxisSize.min,children:[
      TextField(controller:n,decoration:const InputDecoration(labelText:'የIGA ስም')),
      TextField(controller:a,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'ገቢ በብር')),
      TextField(controller:note,decoration:const InputDecoration(labelText:'ማብራሪያ'))
    ]),actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('ሰርዝ')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('አስቀምጥ'))]));
    if(ok==true&&n.text.trim().isNotEmpty){await AppDb.addIga({'name':n.text.trim(),'income':double.tryParse(a.text)??0,'status':'ንቁ','note':note.text});load();}
  }
  @override Widget build(BuildContext context)=>Scaffold(body:ListView.builder(itemCount:rows.length,itemBuilder:(c,i){final r=rows[i];return Card(child:ListTile(leading:const Icon(Icons.store),title:Text('${r['name']}'),subtitle:Text('ገቢ: ${r['income']} ብር • ${r['status']}'),trailing:IconButton(onPressed:()async{await AppDb.deleteIga(r['id'] as int);load();},icon:const Icon(Icons.delete))));}),floatingActionButton:FloatingActionButton(onPressed:add,child:const Icon(Icons.add)));
}

class ProjectsPage extends StatefulWidget {
  const ProjectsPage({super.key});
  @override State<ProjectsPage> createState()=>_ProjectsPageState();
}
class _ProjectsPageState extends State<ProjectsPage>{
  List<Map<String,Object?>> rows=[];
  @override void initState(){super.initState();load();}
  Future<void> load()async{rows=await AppDb.projects();if(mounted)setState((){});}
  Future<void> add()async{
    final n=TextEditingController(),b=TextEditingController(),ben=TextEditingController();
    final ok=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(title:const Text('አዲስ ፕሮጀክት'),content:Column(mainAxisSize:MainAxisSize.min,children:[
      TextField(controller:n,decoration:const InputDecoration(labelText:'የፕሮጀክት ስም')),
      TextField(controller:b,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'በጀት በብር')),
      TextField(controller:ben,decoration:const InputDecoration(labelText:'ተጠቃሚዎች'))
    ]),actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('ሰርዝ')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('አስቀምጥ'))]));
    if(ok==true&&n.text.trim().isNotEmpty){await AppDb.addProject({'name':n.text.trim(),'budget':double.tryParse(b.text)??0,'status':'በሂደት','beneficiaries':ben.text});load();}
  }
  @override Widget build(BuildContext context)=>Scaffold(body:ListView.builder(itemCount:rows.length,itemBuilder:(c,i){final r=rows[i];return Card(child:ListTile(leading:const Icon(Icons.folder),title:Text('${r['name']}'),subtitle:Text('በጀት: ${r['budget']} ብር • ${r['status']}\nተጠቃሚ: ${r['beneficiaries']??''}'),trailing:IconButton(onPressed:()async{await AppDb.deleteProject(r['id'] as int);load();},icon:const Icon(Icons.delete))));}),floatingActionButton:FloatingActionButton(onPressed:add,child:const Icon(Icons.add)));
}

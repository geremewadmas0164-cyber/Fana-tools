import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class AppDb {
  static Database? _db;

  static Future<Database> get db async {
    if (_db != null) return _db!;
    _db = await _open();
    return _db!;
  }

  static Future<Database> _open() async {
    final path = join(await getDatabasesPath(), 'fana_tools.db');
    return openDatabase(path, version: 1, onCreate: (d, v) async {
      await d.execute('CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, password TEXT NOT NULL, role TEXT NOT NULL)');
      await d.execute('CREATE TABLE members(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT, type TEXT, joined TEXT)');
      await d.execute('CREATE TABLE finance(id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, amount REAL NOT NULL, category TEXT, note TEXT, date TEXT NOT NULL)');
      await d.execute('CREATE TABLE iga(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, income REAL NOT NULL, status TEXT, note TEXT)');
      await d.execute('CREATE TABLE projects(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, budget REAL NOT NULL, status TEXT, beneficiaries TEXT)');
      await d.insert('users', {'username': 'admin', 'password': '1234', 'role': 'admin'});
    });
  }

  static Future<bool> login(String u, String p) async {
    final r = await (await db).query('users',
      where: 'username=? AND password=?', whereArgs: [u.trim(), p], limit: 1);
    return r.isNotEmpty;
  }

  static Future<List<Map<String,Object?>>> members([String q='']) async {
    final d = await db;
    if (q.trim().isEmpty) return d.query('members', orderBy: 'id DESC');
    return d.query('members', where: 'name LIKE ? OR phone LIKE ?',
      whereArgs: ['%$q%', '%$q%'], orderBy: 'id DESC');
  }
  static Future<int> addMember(Map<String,Object?> x) async => (await db).insert('members', x);
  static Future<int> updateMember(int id, Map<String,Object?> x) async => (await db).update('members', x, where:'id=?', whereArgs:[id]);
  static Future<int> deleteMember(int id) async => (await db).delete('members', where:'id=?', whereArgs:[id]);

  static Future<List<Map<String,Object?>>> finance() async => (await db).query('finance', orderBy:'id DESC');
  static Future<int> addFinance(Map<String,Object?> x) async => (await db).insert('finance', x);
  static Future<int> deleteFinance(int id) async => (await db).delete('finance', where:'id=?', whereArgs:[id]);

  static Future<List<Map<String,Object?>>> iga() async => (await db).query('iga', orderBy:'id DESC');
  static Future<int> addIga(Map<String,Object?> x) async => (await db).insert('iga', x);
  static Future<int> deleteIga(int id) async => (await db).delete('iga', where:'id=?', whereArgs:[id]);

  static Future<List<Map<String,Object?>>> projects() async => (await db).query('projects', orderBy:'id DESC');
  static Future<int> addProject(Map<String,Object?> x) async => (await db).insert('projects', x);
  static Future<int> deleteProject(int id) async => (await db).delete('projects', where:'id=?', whereArgs:[id]);

  static Future<Map<String,double>> totals() async {
    final d = await db;
    final i = await d.rawQuery("SELECT COALESCE(SUM(amount),0) t FROM finance WHERE kind='income'");
    final e = await d.rawQuery("SELECT COALESCE(SUM(amount),0) t FROM finance WHERE kind='expense'");
    final m = await d.rawQuery("SELECT COUNT(*) t FROM members");
    final income = (i.first['t'] as num).toDouble();
    final expense = (e.first['t'] as num).toDouble();
    return {'income':income, 'expense':expense, 'balance':income-expense,
      'members':(m.first['t'] as num).toDouble()};
  }
}
